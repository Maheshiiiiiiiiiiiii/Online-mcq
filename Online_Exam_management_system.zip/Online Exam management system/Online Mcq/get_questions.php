<!DOCTYPE html>
<html>

<head>
    <title>Add Questions</title>
    <link rel="stylesheet" href="style2.css">
    <style>
        .panel-open {
            display: block;
        }

        .panel-closed {
            display: none;
        }
    </style>
    <script>
        function toggleSection() {
            var section40 = document.querySelector('.section-40');
            var addQuestionBtn = document.querySelector('.addQBtn');

            if (section40.classList.contains('panel-open')) {
                section40.classList.remove('panel-open');
                section40.classList.add('panel-closed');
                addQuestionBtn.innerText = 'Add Question';
            } else {
                section40.classList.remove('panel-closed');
                section40.classList.add('panel-open');
                addQuestionBtn.innerText = 'Close';
            }
        }

        function submitAnswers() {
            var question = document.getElementById('question').value;
            var answer1 = document.getElementById('answer1').value;
            var answer2 = document.getElementById('answer2').value;
            var answer3 = document.getElementById('answer3').value;
            var answer4 = document.getElementById('answer4').value;

            var correctAnswer;
            var radioButtons = document.getElementsByName('correctAnswer');
            for (var i = 0; i < radioButtons.length; i++) {
                if (radioButtons[i].checked) {
                    correctAnswer = radioButtons[i].value;
                    break;
                }
            }

            // Create a new table row
            var table = document.getElementById('questionTable');
            var newRow = table.insertRow();

            // Create cells and set values
            var questionCell = newRow.insertCell();
            questionCell.textContent = question;

            var answerCell = newRow.insertCell();
            var answerList = document.createElement('ul');
            answerList.innerHTML = `
                <li>${answer1}</li>
                <li>${answer2}</li>
                <li>${answer3}</li>
                <li>${answer4}</li>
            `;
            answerCell.appendChild(answerList);

            var correctAnswerCell = newRow.insertCell();
            correctAnswerCell.textContent = correctAnswer;

            // Clear the input fields
            document.getElementById('question').value = '';
            document.getElementById('answer1').value = '';
            document.getElementById('answer2').value = '';
            document.getElementById('answer3').value = '';
            document.getElementById('answer4').value = '';

            // Send the form data to the server (you may use AJAX or modify the form action to submit to a PHP script)
        }
    </script>
</head>

<body>
    <div class="container">
        <div class="section section-60">
            <!-- Content for the first section -->
            <button class="back"><i class="fa-solid fa-chevron-left"></i></button>
            <div>
                <button class="addQBtn" onclick="toggleSection()">Add Question</button>
                <label class="label">Question list</label>
            </div>
            <div>
                <table id="questionTable">
                    <thead>
                        <tr>
                            <th>Question</th>
                            <th>Answers</th>
                            <th>Correct Answer</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <form action="insert_exam.php" method="POST">
                <div class="bottom">
                    <input type="text" id="text" name="examName" placeholder="Exam name">
                    <input type="date" id="date" name="date">
                    <input type="time" id="duration" name="duration">
                    <button class="pubBTn" type="submit" name="publish_btn" value="Publish">Publish Paper</button>
                </div>
            </form>
        </div>
        
        <div class="section section-40 panel-closed">
            <div class="myclass">
                <form   onsubmit="submitAnswers(); return false;">
                    <input type="text" name="question" placeholder="Question name" id="question">
                    <div class="answerPanel">
                        <label class="label">Answers list</label>
                        <div>
                            <input type="radio" name="correctAnswer" value="1">
                            <input name="answer1" type="text" placeholder="Answer 1" id="answer1">
                        </div>
                        <div>
                            <input type="radio" name="correctAnswer" value="2">
                            <input name="answer2" type="text" placeholder="Answer 2" id="answer2">
                        </div>
                        <div>
                            <input type="radio" name="correctAnswer" value="3">
                            <input name="answer3" type="text" placeholder="Answer 3" id="answer3">
                        </div>
                        <div>
                            <input type="radio" name="correctAnswer" value="4">
                            <input name="answer4" type="text" placeholder="Answer 4" id="answer4">
                        </div>
                        <button class="save" type="submit" name="save">Save</button>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
