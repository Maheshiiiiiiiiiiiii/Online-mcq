


<!DOCTYPE html>
<html>

<head>
    <button type="button" onclick="goBack()" class="back"><</button>
    <meta name="_viewpoint" content="width=device-width, initial-scale=1.0">
    <title>Exam</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/e042178d2a.js" crossorigin="anonymous"></script>
    <style>
        .table1 button {
            width: 100%;
            height: 100%;
            font-size: 20px;
            text-align: justify;
            border: none;
            background-color: transparent;
            cursor: pointer;
        }

        button:hover {
            background-color: lightgray;
        }
        .back{
            background-color: white;
            border: none;
            font-size: 34px;
            font-weight: 100;
        }
    </style>
    <script>
        function startTest(exsamId) {
            window.location.href = "mcq.php?exsamId=" + encodeURIComponent(exsamId);
        }
        function goBack() {
            window.history.back();
        }
    </script>


</head>

<body>
    <div class="container">
        <form id="searchForm" method="GET">
            <input type="text" placeholder="Search" name="search">
            <button type="submit">Search</button>
        </form>
    </div>
    <div class="table1">
        <table id="examTable">
            <thead>
                <tr>
                    <th>Exam</th>
                    <th>Starting Time</th>
                    <th>Exam duration</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <td><button onclick="startTest('<?php echo $row['exsamId']; ?>')"><?php echo $row['examName']; ?></button></td>
                        <td><?php echo $row['lastUpdated']; ?></td>
                        <td><?php echo $row['duration']; ?></td>
                        <td><?php echo ($row['st_status'] == 1) ? 'Attend' : 'Pending'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>

</html>
