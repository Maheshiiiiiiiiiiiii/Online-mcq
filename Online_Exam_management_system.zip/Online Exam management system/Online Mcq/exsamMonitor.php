<?php
require_once 'includes/dbh.inc.php'; // Make sure to include the database connection file


// Check if the exam ID is provided in the URL
if (isset($_GET['id'])) {
    $examId = $_GET['id'];

    // Fetch the exam details from the database based on the exam ID
    $sql = "SELECT * FROM exam WHERE exsamId = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $examId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Check if the exam exists
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Exam not found.";
        exit;
    }
} else {
    header("Location: exam.php");
    exit;
}


// Handle the form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the exam ID is provided
    if (isset($_POST['exam_id'])) {
        $examId = $_POST['exam_id'];

        // Delete the exam from the database
        $sql = "DELETE FROM exam WHERE exsamId = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $examId);
        mysqli_stmt_execute($stmt);

        // Redirect to the login page
        header("Location: logn.php");
        exit;
    }
}

// Get the count of students who have status 1 for the given exam
$sql = "SELECT COUNT(*) AS completedCount FROM student_has_exsams WHERE exam_idSt = ? AND st_status = 1";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $examId);
mysqli_stmt_execute($stmt);
$countResult = mysqli_stmt_get_result($stmt);
$countRow = mysqli_fetch_assoc($countResult);
$completedStudentsCount = $countRow['completedCount'];

// Get the total number of students attending the exam
$sql = "SELECT COUNT(*) AS totalStudentsCount FROM student_has_exsams WHERE exam_idSt = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $examId);
mysqli_stmt_execute($stmt);
$totalResult = mysqli_stmt_get_result($stmt);
$totalRow = mysqli_fetch_assoc($totalResult);
$totalStudentsCount = $totalRow['totalStudentsCount'];
if($totalStudentsCount==0)
{
    echo "There are no student attend yet!";

}else{
// Calculate the fraction of completed students
$completedFraction = $completedStudentsCount / $totalStudentsCount;
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="_viewpoint" content="width=device-width, initial-scale=1.0">
    <title>Exam Monitor</title>
    
    <script src="https://kit.fontawesome.com/e042178d2a.js" crossorigin="anonymous"></script>
    <style>
        .container {
            display: flex;
            flex-wrap: wrap;
        }

        .box {
            width: calc(50% - 20px);
            height: 200px;
            border: 1px solid #ccc;
            margin-bottom: 20px;
            padding: 20px;
            box-sizing: border-box;
        }

        .left-box1 {
            border: 1px solid #906cf1;
            margin-left: 7px;
            height: 200px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .left-box1 label {
            font-size: 20px;
            margin-bottom: 10px;
        }

        .left-box1 .completed-count {
            font-size: 70px;
            color: black;
            font-weight: bold;
        }

        .left-box2 {
            margin-left: 7px;
            border: 1px solid #906cf1;
        }

        .right-box {
            border: 1px solid #906cf1;
            margin-left: 7px;
            height: 200px;
        }

        .date-time {
            font-size: 16px;
            color: #333;
            margin-top: 10px;
        }

        .label {
            font-size: 20px;
            margin-bottom: 20px;
        }

        button {
            margin-top: auto;
            border-radius: 5px;
            margin-left: 30cm;
            margin-right: 7px;
            width: 160px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #cc2f2f;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>

<script>
     function startCountdown(minutes) {
    var countdownElement = document.getElementById("countdown");
    var countDownDate = new Date().getTime() + minutes * 60000;

    var countdownTimer = setInterval(function() {
        var now = new Date().getTime();
        var distance = countDownDate - now;

        var minutesRemaining = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        var secondsRemaining = Math.floor((distance % (1000 * 60)) / 1000);

        countdownElement.innerText = minutesRemaining + "m " + secondsRemaining + "s ";

        if (distance < 0) {
            clearInterval(countdownTimer);
            countdownElement.innerText = "Time Up!";
        }

        // Compare the current time with the start time
        var startTime = new Date("<?php echo $row['startTime']; ?>").getTime();
        var currentTime = new Date().getTime();
        var timeDiff = currentTime - startTime;
        var hoursDiff = Math.floor(timeDiff / (1000 * 60 * 60));

        // Display alert if more than 1 hour has passed
        if (hoursDiff > 1) {
            clearInterval(countdownTimer);
            alert("More than 1 hour has passed since the exam started!");
        }
    }, 1000);
}

    
    </script>
</head>
<body onload="startCountdown(60)">
    <div class="exam-name" style="font-size: 20px; margin: 10px; width: 300px; height:40px;">
        <?php echo htmlspecialchars($row['examName']); ?>
    </div>

    <div class="container">
        <div class="box left-box1">
            <!-- Content for the first left box -->
            <label>Exam completed</label>
            <div class="completed-count">
                 <?php echo $completedStudentsCount; ?>/<?php echo $totalStudentsCount; ?>
            </div>
            <label>Time Left</label>
            <div id="countdown" class="countdown"></div>
        </div>

        <div class="box left-box2">
            <!-- Content for the second left box -->
            <div class="label">
                <label>Attending Student List</label>
            </div>

            <?php
    // Fetch the attending students for the exam
    $sql = "SELECT * FROM `student_has_exsams` WHERE `exam_idSt` = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $examId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    // Check if there are any attending students
    if (mysqli_num_rows($result) > 0) {
        while ($student = mysqli_fetch_assoc($result)) {
            echo "<div class='output-box'>";
            echo "<p style='border: 1px solid #ccc; padding: 7px;'> <span style='font-size: 18px;'> " . $student['name'] . "<span style='margin-left: 300px;'> <span style='color: green;'><span style='font-size: 18px; '>";

            if ($student['st_status'] == 1) {
                echo "Completed";
            } else {
                echo "-";
            }

            echo "</span></span></p><br>";
            echo "</div>";
        }
    } else {
        echo "No attending students.";
    }
?>

        </div>

        <div class="box right-box">
            <!-- Content for the right box -->
            <div class="date-time">Exam started Date: <?php echo date('Y-m-d'); ?></div>
            <div class="date-time">Exam started Time: <?php echo date('H:i:s'); ?></div>
        </div>
    </div>
    <button type="submit" id="closeButton" onclick="closePage()">End Exam</button>

<script>
  function closePage() {
    
    window.location.href = "logn.php";
  }
</script>

   
</body>

</html>
