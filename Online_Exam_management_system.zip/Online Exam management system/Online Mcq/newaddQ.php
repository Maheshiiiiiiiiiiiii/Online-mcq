<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style2.css">

  <style>
    body {
      display: flex;
      justify-content: flex-start;
      align-items: flex-start;
    }
    #panel {
      width: 380px;
      height: calc(100% - 14px); /* Accounting for top and bottom margins */
      border: 1px solid #906cf1;
      position: fixed;
      top: 7px;
      bottom: 7px;
      right: -400px;
      transition: right 0.3s ease-in-out;
      margin: 7px 5px;
    }
    
    #panel.open {
      right: 0;
    }
    
    #content {
      padding: 20px;
    }
    #examName {
      margin-top: 10px;
      margin-left: 10px;
    }

    #openBtn {
        margin-top: 10px;
    margin-bottom: 7px;
    border-radius: 5px;
    margin-left: 20cm;
    
    width: 160px;
    padding: 10px 20px;
    font-size: 16px;
    background-color: #cc2f2f;
    color: white;
    border: none;
    cursor: pointer;
  }
  .inputFields{
    display: flex;
    justify-content: flex-end;
  }
  .inputFields inputFields {
      margin-left: 10px;
    }
  .inputFieldsbtn {
      display: flex;
      justify-content: flex-end;
    }

    .inputFieldsbtn button {
      margin-left: 10px;
    }
  .openBtn:hover {
    background-color: #e9604e;
  }
  

  input[type="date"] {
    margin-top: 30px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    width: 200px;
  }
  input[type="time"]
  {
    margin-top: 30px;
    margin-right: 7px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    width: 200px;
  }
    input[type="text"] {
    margin-top: 30px;
    margin-right: 7px;
    height: 18px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 14px;
    width: 200px;
    
  }

  .draft_btns{
    margin-top: 10px;
    border-radius: 5px;
    
    width: 160px;
    padding: 10px 20px;
    font-size: 16px;
    background-color: green;
    color: white;
    border: none;
    cursor: pointer;
  }
  .draft_btns:hover {
    background-color: #e9604e;
  }
  .pubBTn {
    margin-top: 10px;
    border-radius: 5px;
    width: 260px;
    margin-left: 45px;
    padding: 10px 20px;
    font-size: 16px;
    background-color: #a938c5;
    color: white;
    border: none;
    cursor: pointer;
  }
  .pubBTn:hover {
    background-color: #e6ace1;
  }

  table {
  margin-top: auto;
  margin-left: 10px;
    }

    th, td {
      padding: 8px;
      border-bottom: 1px solid #ccc;
      text-align: left;
    }
.back{
background-image: element(#906cf1);
font-size: 34px;
font-weight: 100;
}
  </style>
</head>
<body>


  
<div class="container">
        <div class="section-60">
        <button type="button" onclick="goBack()" class="back"><</button>
        <button id="openBtn">Add Question</button>
            <!-- Content for the first section -->
            <form action="insert_exam.php" method="POST">
    <div>
        <div>
            <table id="questionTable">
                <thead>
                    <tr>
                        <th>Question</th>
                        <th>Answers</th>
                        <th>Correct Answer</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>

        <div class="bottom">
            <div class="inputFields">
                <input type="text" id="text" name="examName" placeholder="Exam name" required>
                <input type="date" id="date" name="date" required>
                <input type="time" id="duration" name="duration" required>
                <input type="text" id="durationInput" onblur="validateDuration(this)">
            </div>
            <div class="inputFieldsbtn">
                <button class="pubBTn" type="submit" name="publish_btn" value="Publish">Publish Paper</button>
                <button class="draft_btns" type="submit" name="draft_btn" value="Save as Draft">Save as Draft</button>
            </div>
        </div>
    </div>

    <div class="section-40">
        <div id="panel">
            <div id="content">
                <!-- Panel content goes here -->
                <input type="text" name="question" placeholder="Question name" id="question">
                <div class="answerPanel">
                    <label class="label">Answers list</label>
                    <div>
                        <input type="radio" name="correctAnswer" value="1">
                        <input name="answer1" type="text" placeholder="Answer 1" id="answer1" required>
                    </div>
                    <div>
                        <input type="radio" name="correctAnswer" value="2">
                        <input name="answer2" type="text" placeholder="Answer 2" id="answer2" required>
                    </div>
                    <div>
                        <input type="radio" name="correctAnswer" value="3">
                        <input name="answer3" type="text" placeholder="Answer 3" id="answer3" required>
                    </div>
                    <div>
                        <input type="radio" name="correctAnswer" value="4">
                        <input name="answer4" type="text" placeholder="Answer 4" id="answer4" required>
                    </div>
                    <button class="save" type="submit" name="save" onclick="saveFunction()">Save</button>
                </div>
            </div>
        </div>
    </div>
</form>

    </div>
  </div>
        </div>

  <script>
    document.getElementById('openBtn').addEventListener('click', function() {
      document.getElementById('panel').classList.toggle('open');
    });

    function handlePublish() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      alert('Successfully added!');
      window.location.href = 'exam.php';
    }
  };
  xhttp.open('POST', 'insert_exam.php', true);
  xhttp.send(new FormData(document.querySelector('form')));
}

    function submitAnswers() {
            var question = document.getElementById('question').value;
            var answer1 = document.getElementById('answer1').value;
            var answer2 = document.getElementById('answer2').value;
            var answer3 = document.getElementById('answer3').value;
            var answer4 = document.getElementById('answer4').value;


          

            var correctAnswer;
            var radioButtons = document.getElementsByName('correctAnswer');
            for (var i = 0; i < radioButtons.length; i++) {
                if (radioButtons[i].checked) {
                    correctAnswer = radioButtons[i].value;
                    break;
                }
            }

            var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      // Success: the question has been added to the database
      alert('Question added successfully!');
      clearForm();
    }
  };
  xhttp.open('POST', 'insert_question.php', true);
  xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
  xhttp.send(
    'question=' + encodeURIComponent(question) +
    '&answer1=' + encodeURIComponent(answer1) +
    '&answer2=' + encodeURIComponent(answer2) +
    '&answer3=' + encodeURIComponent(answer3) +
    '&answer4=' + encodeURIComponent(answer4) +
    '&correctAnswer=' + encodeURIComponent(correctAnswer)
  );


      }

    function  saveFunction(){

      var question = document.getElementById('question').value;
            var answer1 = document.getElementById('answer1').value;
            var answer2 = document.getElementById('answer2').value;
            var answer3 = document.getElementById('answer3').value;
            var answer4 = document.getElementById('answer4').value;


            var correctAnswer;
            var radioButtons = document.getElementsByName('correctAnswer');
            for (var i = 0; i < radioButtons.length; i++) {
                if (radioButtons[i].checked) {
                    correctAnswer = radioButtons[i].value;
                    break;
                }
            }
                  // Create a new table row
                  var table = document.getElementById('questionTable');
            var newRow = table.insertRow();

            // Create cells and set values
            var questionCell = newRow.insertCell();
            questionCell.textContent = question;

            var answerCell = newRow.insertCell();
            var answerList = document.createElement('ul');
            answerList.innerHTML = `
                <li>${answer1}</li>
                <li>${answer2}</li>
                <li>${answer3}</li>
                <li>${answer4}</li>
            `;
            answerCell.appendChild(answerList);

            var correctAnswerCell = newRow.insertCell();
            correctAnswerCell.textContent = correctAnswer;

            // Clear the input fields
            document.getElementById('question').value = '';
            document.getElementById('answer1').value = '';
            document.getElementById('answer2').value = '';
            document.getElementById('answer3').value = '';
            document.getElementById('answer4').value = '';

            var deleteCell = newRow.insertCell();
      var deleteButton = document.createElement('button');
      deleteButton.textContent = 'Delete';
      deleteButton.addEventListener('click', function() {
        table.deleteRow(newRow.rowIndex);
      });
      deleteCell.appendChild(deleteButton);


      }
    

    function goBack() {
    window.history.back();
  }

  function validateDuration(input) {
      // Regular expression pattern to validate the format (HH:MM:SS)
      var pattern = /^([0-9]{2}):([0-5][0-9]):([0-5][0-9])$/;
      
      if (!input.value.match(pattern)) {
        alert("Invalid duration format! Please use the format HH:MM:SS.");
        input.value = ""; // Clear the input field
      }
    }
  </script>
</body>
</html>
