
<!DOCTYPE html>
<html>

<head>
    <meta name="_viewpoint" content="width=device-width, initial-scale=1.0">
    <title>Exam</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/e042178d2a.js" crossorigin="anonymous"></script>
    <style>
        .back{
  background: none;
  border: none;
  font-size: 34px;
  font-weight: 100;
  }

  .logout{
    background-color: white;
    border: none;
    font-size: 20px;
    font-style: italic;
    font-weight: 400;
    margin-left: 10px;
  }
    </style>
</head>
<body>
<button type="button" onclick="goBack()" class="back"><</button>
    <div class="container">
        <div class="search-container">
            <form action="" method="GET">
                <input type="text" name="search" placeholder="Search">
                <button type="submit" name="submit">Search</button>
            </form>
        </div>
        <button class="next-button" onclick="redirectToExamPage()">New Exam</button>
    </div>

    <table id="examTable">
        <thead>
            <tr>
                <th>Exam</th>
                <th>Last Updated</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td><a href="exsamMonitor.php?id=<?php echo $row['exsamId']; ?>"><?php echo $row['examName']; ?></a></td>
                    <td><?php echo $row['lastUpdated']; ?></td>
                    <td><?php echo ($row['status'] == 1) ? 'Publish' : 'Draft'; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <button class="logout" name="logout" onclick="redirectToLogin()">logout</button>
    <script>
        function redirectToExamPage() {
            window.location.href = "newaddQ.php";
        }
        function goBack() {
    window.history.back();
  }
  function redirectToLogin() {
    window.location.href = "logn.php";
  }
    </script>
</body>

</html>
