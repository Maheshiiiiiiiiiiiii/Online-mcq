


<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            padding: 0;
           
        }
        
        .login-box {
            display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
            width: 600px;
            height: 500px;
            border: 3px solid #E6E6FA;
            padding: 20px;
            border-radius: 5px;
            
        }
        
        .login-box h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .login-box label {
            display: block;
            margin-bottom: 5px;
            margin-left: 116px;
            margin-top: 30px;
        }
        
        .login-box input[type="email"],
        .login-box input[type="password"] {
            width: 350px;
            height: 35px;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-bottom: 10px;
            margin-left: 116px;
        }
        
        .login-box input[type="submit"] {
            width: 368px;
            height: 45px;
            margin-left: 116px;
           
            padding: 8px;
            font-size: 16px;
            background: #5456ca;
            color: blanchedalmond;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        
        .login-box input[type="submit"]:hover {
            background-color: #9370DB;
        }
    </style>
</head>
<body>
    <div class="login-box">
       
        
        <form method="POST" action="">
            <label for="email">Email Address:</label>
            <input type="email" name="email" required>
            
            <label for="password">Password:</label>
            <input type="password" name="password" required>
            
            <input type="submit" value="Sign in">
        </form>
    </div>
</body>
</html>
