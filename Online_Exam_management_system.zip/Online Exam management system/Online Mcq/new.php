<!DOCTYPE html>
<html>
<head>
    <title>Questionnaire</title>
    <style>
        /* Add some basic styles for the page */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }
        
        h1 {
            text-align: center;
        }
        
        
        .question-container {
            max-width: 600px;
            margin: 0 auto;
            border: 1px solid #ccc;
            padding: 20px;
        }
        
        .question {
            margin-bottom: 10px;
        }
        
        .answer {
            margin-bottom: 5px;
        }
        
        .button-container {
            text-align: center;
            margin-top: 20px;
        }
        
        .button {
            padding: 10px 20px;
            font-size: 16px;
            margin-right: 10px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>Questionnaire</h1>
    <div class="question-container">
        <div class="question" id="question"></div>
        <div class="answer">
            <label><input type="radio" name="answer" value="1"> <span id="answer1"></span></label>
        </div>
        <div class="answer">
            <label><input type="radio" name="answer" value="2"> <span id="answer2"></span></label>
        </div>
        <div class="answer">
            <label><input type="radio" name="answer" value="3"> <span id="answer3"></span></label>
        </div>
        <div class="answer">
            <label><input type="radio" name="answer" value="4"> <span id="answer4"></span></label>
        </div>
        <div class="button-container">
            <button class="button" id="previousButton">Previous</button>
            <button class="button" id="nextButton">Next</button>
            <button class="button" id="completeButton">Complete</button>
        </div>
    </div>

    <script>
        // Retrieve questions from the server
        function retrieveQuestions() {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var questions = JSON.parse(xhr.responseText);
                    initializeQuiz(questions);
                }
            };
            xhr.open("GET", "get_questions.php", true);
            xhr.send();
        }

        // Initialize the quiz with retrieved questions
        function initializeQuiz(questions) {
            var currentQuestionIndex = 0;
            var totalMarks = 0;

            // Function to display the current question
            function displayQuestion() {
                var questionElement = document.getElementById("question");
                var answer1Element = document.getElementById("answer1");
                var answer2Element = document.getElementById("answer2");
                var answer3Element = document.getElementById("answer3");
                var answer4Element = document.getElementById("answer4");

                var currentQuestion = questions[currentQuestionIndex];
                questionElement.innerText = currentQuestion.question;
                answer1Element.innerText = currentQuestion.answer1;
                answer2Element.innerText = currentQuestion.answer2;
                answer3Element.innerText = currentQuestion.answer3;
                answer4Element.innerText = currentQuestion.answer4;
            }

            // Function to handle the "Next" button click
            function nextQuestion() {
                if (currentQuestionIndex < questions.length - 1) {
                    currentQuestionIndex++;
                    displayQuestion();
                } else {
                    alert("No more questions.");
                }
            }

            // Function to handle the "Previous" button click
            function previousQuestion() {
                if (currentQuestionIndex > 0) {
                    currentQuestionIndex--;
                    displayQuestion();
                } else {
                    alert("This is the first question.");
                }
            }

            // Function to handle the "Complete" button click
            function completeTest() {
                // Calculate total marks
                var selectedAnswer = document.querySelector('input[name="answer"]:checked');
                if (selectedAnswer) {
                    var userAnswer = parseInt(selectedAnswer.value);
                    var currentQuestion = questions[currentQuestionIndex];
                    if (userAnswer === currentQuestion.correct_answer) {
                        totalMarks++;
                    }
                }

                alert("Total Marks: " + totalMarks);
                // You can perform any additional actions here, such as sending the marks to the server

                // Reset the variables for a new test
                currentQuestionIndex = 0;
                totalMarks = 0;
                displayQuestion();
            }

            // Attach event listeners to the buttons
            document.getElementById("nextButton").addEventListener("click", nextQuestion);
            document.getElementById("previousButton").addEventListener("click", previousQuestion);
            document.getElementById("completeButton").addEventListener("click", completeTest);

            // Display the first question
            displayQuestion();
        }

        // Retrieve questions on page load
        retrieveQuestions();
    </script>
</body>
</html>
