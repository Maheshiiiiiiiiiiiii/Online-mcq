<!DOCTYPE html>
<html>
<head>
  <title>Exam Results</title>
  <style>
    /* CSS styles for centering the elements */
    body {
      display: flex;
      flex-direction: column;
      align-items: center;
      
      justify-content: center;
      height: 100vh;
      margin: 0;
      font-family: Arial, sans-serif;
    }
    
    .container2 {
      background-color: white;
      border: 3px solid #aca7e7;
      padding: 20px;
      text-align: left;
      margin-bottom: 10px;
      width: 500px;
      height: 400px;
      overflow-y: auto;
    }
    
    .container1 {
      background-color: white;
      border: 3px solid #aca7e7;
      padding: 20px;
      height: 400px;
      text-align: center;
      margin-bottom: 10px;
      margin-top: 8px;
      width: 500px;
    }
    
    .correct-answer {
      background-color: #29AB87;
      color: white;
      padding: 10px;
      border: none;
    }
    
    #closeButton {
      margin-top: 10px;
      margin-bottom: 10px;
      width: 100px;
      height: 55px;
      font-size: 18px;
      font-family: 'Times New Roman', Times, serif;
      border: none;
      background-color: #C4CDC7;
      border-radius: 3px;
    }
    
    .question-box {
      background-color: white;
      border: 1px solid #aca7e7;
      padding: 7px;
      margin-bottom: 10px;
    }
    
    .question {
      display: inline-block;
      font-weight: bold;
      margin-right: 60%;
    }
    
    .correctness {
      display: inline-block;
      font-style: italic;
    }
    
    .correct {
      color: green;
    }
    
    .incorrect {
      color: red;
    }
   
  </style>
</head>
<body>
  <?php
    session_start();
    $score = $_SESSION['score'];
    $totalQuestions = $_SESSION['totalQuestions'];
    $answerValue = $_SESSION['answerValue'];
    $examID=$_SESSION['examID'];
    $percentage = ($score / $totalQuestions) * 100;
    $resultText = ($percentage >= 35) ? "Pass" : "Failed";
  ?>

  <div class="container1">
    <label id="label1">Exam completed</label>
    <p>
      <?php
        // Display the score, percentage, and result
        echo " <span class='" . ($resultText === 'Pass' ? 'pass' : 'failed') . "' style='color: " . ($resultText === 'Pass' ? 'green' : 'red') . "; font-size: 50px;'>$resultText</span>";
        echo "<br>";
        echo '<span style="margin-right: 10px; font-size: 16px;"><br>Points: ' . $score . '</span><span style="margin-right: 10px; font-size: 20px;">' . $percentage . '%</span>';
      ?>
    </p>
  </div>

  <div class="container2">
    <?php
    // Connect to your database and fetch the questions from the table
    require_once "includes/dbh.inc.php";

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }

    // Fetch the questions from the table
    $sql = "SELECT question, answer1, answer2, answer3, answer4, correct_answer FROM addquestions WHERE examid = '$examID'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      $questionNumber = 1; // Counter for question numbers
    
      while ($row = $result->fetch_assoc()) {
        $question = $row['question'];
        $correctness = $answerValue[$questionNumber - 1] ? "Correct" : "Incorrect";
    
        // Display the question and its correctness status
        echo '<div class="question-box">';
        echo '<span class="question">Question ' . $questionNumber . ': '  . '</span>';
        echo '<span class="correctness ' . ($answerValue[$questionNumber - 1] ? 'correct' : 'incorrect') . '">' . $correctness . '</span>';
        echo '</div>';
    
        $questionNumber++;
    
        // Stop displaying questions if we've reached the desired number
        if ($questionNumber > $totalQuestions) {
          break;
        }
      }
    }else {
      echo "<p>No questions found.</p>";
    }

    // Close the database connection
    $conn->close();
    ?>
  </div>

  <button id="closeButton" onclick="closePage()">Close</button>

  <script>
    function closePage() {
      window.location.href = "logn.php";
    }
  </script>
</body>
</html>