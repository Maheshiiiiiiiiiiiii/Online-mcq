<?php
session_start();
require_once "includes/dbh.inc.php";

// Retrieve the exam ID from the query parameter
$examID = $_GET['exsamId'];

// Fetch the exam name from the database based on the exam ID
$sql = "SELECT examName FROM exam WHERE exsamId = '$examID'";
$result = mysqli_query($conn, $sql);

// Check if the query executed successfully
if ($result === false) {
    // Handle the case when the query encounters an error
    echo "Error executing SQL query: " . mysqli_error($conn);
    exit;
}

// Check if the exam exists
if (mysqli_num_rows($result) > 0) {
    $exam = mysqli_fetch_assoc($result);
    $examName = $exam['examName'];

    // Fetch the MCQs belonging to the specified exam from the database
    $sql = "SELECT question, answer1, answer2, answer3, answer4, correct_answer FROM addquestions WHERE examId = '$examID'";
    $result = mysqli_query($conn, $sql);

    // Check if the query executed successfully
    if ($result === false) {
        // Handle the case when the query encounters an error
        echo "Error executing SQL query: " . mysqli_error($conn);
        exit;
    }

    // Check if there are any MCQs
    if (mysqli_num_rows($result) > 0) {
        $mcqs = mysqli_fetch_all($result, MYSQLI_ASSOC);
    } else {
        $mcqs = [];
    }
} else {
    // Handle the case when the exam does not exist
    echo "Exam not found.";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $score = 0;
    $answerValue = [];
    // Iterate over submitted answers and compare with correct answers
    foreach ($mcqs as $index => $mcq) {
      $questionNumber = $index + 1;
      $submittedAnswerKey = "answer_" . $questionNumber;
     
      if (isset($_POST[$submittedAnswerKey])) {
        $submittedAnswer = $_POST[$submittedAnswerKey];
       
        $correctAnswer = $mcq['correct_answer'];
       
        if ($submittedAnswer == $correctAnswer) {
            $score++;
            $answerValue[] = true; // Store true if the answer is correct
        } else {
            $answerValue[] = false; // Store false if the answer is incorrect
        }
      }
    }
  
    $totalQuestions = count($mcqs);
    $_SESSION['score'] = $score;
$_SESSION['answerValue'] = $answerValue;
$_SESSION['totalQuestions'] = $totalQuestions;
header("Location: marks.php");
exit;
  }
  

if (isset($_POST['save'])) {
    session_start();
    $score = $_SESSION['score'];
    $loginId = $_SESSION['login_id'];
    $examId = 1; // Assuming the exam ID is 1
  
    // Save the marks in the database
    $sql = "UPDATE student_has_exsams SET NoCorrectAnswer = $score WHERE login-id = '$loginId' AND exam_idSt = $examId";
    $result = $conn->query($sql);
  
    if ($result) {
      echo "Marks saved successfully.";
    } else {
      echo "Error saving marks: " . $conn->error;
    }
  }
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MCQ</title>
    <!-- Add your CSS and JavaScript files if necessary -->
    <style>
        .question {
            display: none;
        }
        .question.active {
            display: block;
        }
      
    body {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        
        font-family: Arial, sans-serif;
    }

    .mcq-container {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        justify-content: center;
        text-align: left;
        margin-bottom: 20px;
        margin-top: 20px;
        border: 1px solid #906cf1;
        width: 500px;
        height: 200px;
        padding: 20px;
    }

    .question {
        display: none;
    }

    .question.active {
        display: block;
    }

    .navigation-panel {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        margin-bottom: 20px;
    }

    .button-container {
        display: flex;
        justify-content: flex-end;
        margin-top: 20px;
    }

    button {
        padding: 10px 20px;
        margin-left: 10px;
        font-size: 16px;
    }

    .button-container {
        display: flex;
        justify-content: flex-end;
        margin-top: 20px;
    }

    button {
        padding: 10px 20px;
        margin-left: 10px;
        font-size: 16px;
    }

    #closeButton {
        background-color: green;
        color: #fff;
        border: none;
        margin-right: 10px;
        border-radius: 3px;
    }

    #complete {
        background-color: #007bff;
        color: #fff;
        border: none;
         border-radius: 3px;
    }
</style>
</style>

    </style>
    <script>
        function showQuestion(index) {
            var questions = document.getElementsByClassName("question");
            for (var i = 0; i < questions.length; i++) {
                questions[i].classList.remove("active");
            }
            questions[index].classList.add("active");
        }
        function showNextQuestion() {
            var questions = document.getElementsByClassName("question");
            var currentIndex = 0;
            for (var i = 0; i < questions.length; i++) {
                if (questions[i].classList.contains("active")) {
                    currentIndex = i;
                    break;
                }
            }
            var nextIndex = (currentIndex + 1) % questions.length;
            showQuestion(nextIndex);
        }
        function showQuestion(index) {
    var questions = document.getElementsByClassName("question");
    for (var i = 0; i < questions.length; i++) {
        questions[i].classList.remove("active");
    }
    questions[index].classList.add("active");

    // Update the question index label
    var questionIndexLabel = document.getElementById("questionIndexLabel");
    questionIndexLabel.textContent = "Question " + (index + 1) + " of " + questions.length;
}


        function showPreviousQuestion() {
            var questions = document.getElementsByClassName("question");
            var currentIndex = 0;
            for (var i = 0; i < questions.length; i++) {
                if (questions[i].classList.contains("active")) {
                    currentIndex = i;
                    break;
                }
            }
            var previousIndex = (currentIndex - 1 + questions.length) % questions.length;
            showQuestion(previousIndex);
        }

        function startTimer(duration, display) {
            var timer = duration, minutes, seconds;
            setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = minutes + ":" + seconds;

                if (--timer < 0) {
                    timer = 0;
                    // Automatically submit the form when the timer reaches 0
                    document.getElementById("mcq-form").submit();
                }
            }, 1000);
        }
        window.onload = function () {
            var oneHour = 60 * 60,
                display = document.getElementById("timer");
            startTimer(oneHour, display);
        };
    </script>
</head>
<body>
<label style="position: absolute; top: 0; left: 0; margin: 20px;">Multiple Choice Questions - <?php echo $examName; ?></label>

    <div style="text-align: center">Time Remaining: <span id="timer"></span></div>
    <form method="POST" action="">
    <div class="mcq-container">
        <?php foreach ($mcqs as $index => $mcq): ?>
            <div class="question <?php echo ($index === 0) ? 'active' : ''; ?>">
                <h3><?php echo $mcq['question']; ?></h3>
                <ul style="list-style-type: none;">
                    <li>
                        <label>
                            <input type="radio" name="answer_<?php echo $index + 1; ?>" value="1">
                            <?php echo $mcq['answer1']; ?>
                        </label>
                    </li>
                    <li>
                        <label>
                            <input type="radio" name="answer_<?php echo $index + 1; ?>" value="2">
                            <?php echo $mcq['answer2']; ?>
                        </label>
                    </li>
                    <li>
                        <label>
                            <input type="radio" name="answer_<?php echo $index + 1; ?>" value="3">
                            <?php echo $mcq['answer3']; ?>
                        </label>
                    </li>
                    <li>
                        <label>
                            <input type="radio" name="answer_<?php echo $index + 1; ?>" value="4">
                            <?php echo $mcq['answer4']; ?>
                        </label>
                    </li>
                </ul>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="navigation-panel">
        <button type="button" onclick="showPreviousQuestion()">Previous</button>
        <label id="questionIndexLabel"></label>
        <button type="button" onclick="showNextQuestion()">Next</button>
    </div>
    <div class="button-container">
        <button id="closeButton" name="save" onclick="closePage()">Save</button>
        <button id="complete" type="submit" name="complete">Complete</button>
    </div>
    </form>
</body>

</html>
