

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MCQ</title>
    <!-- Add your CSS and JavaScript files if necessary -->
    <style>
        .question {
            display: none;
        }
        .question.active {
            display: block;
        }
    </style>
    <script>
        function showQuestion(index) {
            var questions = document.getElementsByClassName("question");
            for (var i = 0; i < questions.length; i++) {
                questions[i].classList.remove("active");
            }
            questions[index].classList.add("active");
        }
        function showNextQuestion() {
            var questions = document.getElementsByClassName("question");
            var currentIndex = 0;
            for (var i = 0; i < questions.length; i++) {
                if (questions[i].classList.contains("active")) {
                    currentIndex = i;
                    break;
                }
            }
            var nextIndex = (currentIndex + 1) % questions.length;
            showQuestion(nextIndex);
        }
        function showPreviousQuestion() {
            var questions = document.getElementsByClassName("question");
            var currentIndex = 0;
            for (var i = 0; i < questions.length; i++) {
                if (questions[i].classList.contains("active")) {
                    currentIndex = i;
                    break;
                }
            }
            var previousIndex = (currentIndex - 1 + questions.length) % questions.length;
            showQuestion(previousIndex);
        }

        function startTimer(duration, display) {
            var timer = duration, minutes, seconds;
            setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = minutes + ":" + seconds;

                if (--timer < 0) {
                    timer = 0;
                    // Automatically submit the form when the timer reaches 0
                    document.getElementById("mcq-form").submit();
                }
            }, 1000);
        }
        window.onload = function () {
            var oneHour = 60 * 60,
                display = document.getElementById("timer");
            startTimer(oneHour, display);
        };
    </script>
</head>
<body>
    <h1>Multiple Choice Questions - <?php echo $examName; ?></h1>
    <div>Time Remaining: <span id="timer"></span></div>
    <form method="POST" action="">
        <div class="mcq-container">
            <?php foreach ($mcqs as $index => $mcq): ?>
                <div class="question <?php echo ($index === 0) ? 'active' : ''; ?>">
                    <h3><?php echo $mcq['question']; ?></h3>
                    <ul>
                        <li>
                            <label>
                                <input type="radio" name="answer_<?php echo $index + 1; ?>" value="1">
                                <?php echo $mcq['answer1']; ?>
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="radio" name="answer_<?php echo $index + 1; ?>" value="2">
                                <?php echo $mcq['answer2']; ?>
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="radio" name="answer_<?php echo $index + 1; ?>" value="3">
                                <?php echo $mcq['answer3']; ?>
                            </label>
                        </li>
                        <li>
                            <label>
                                <input type="radio" name="answer_<?php echo $index + 1; ?>" value="4">
                                <?php echo $mcq['answer4']; ?>
                            </label>
                        </li>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="navigation-panel">
            <button type="button" onclick="showPreviousQuestion()">Previous</button>
            <button type="button" onclick="showNextQuestion()">Next</button>
        </div>
        <button type="submit">Submit</button>
    </form>
</body>
</html>
